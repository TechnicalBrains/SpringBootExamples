/**
 * 
 */
package com.education.mgmt.sys.service.impl;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.education.mgmt.sys.dto.SearchStudentDetailsDTO;
import com.education.mgmt.sys.dto.StudentCareerDetails;
import com.education.mgmt.sys.service.SearchService;
import com.education.mgmt.sys.util.StudentMarksInfo;

/**
 * @author 611163
 *
 */
@Service
public class SearchServiceImpl implements SearchService {

	public SearchServiceImpl() {
		StudentMarksInfo.buildStudentMarksInfo();
	}
	@Override
	public List<StudentCareerDetails> searchStudentMarksInfo(SearchStudentDetailsDTO searchStudentDetailsDTO) {
		
		if(StringUtils.isNotBlank(searchStudentDetailsDTO.getStandard()) && StringUtils.isBlank(searchStudentDetailsDTO.getGrade())
				&& StringUtils.isBlank(searchStudentDetailsDTO.getStudentCode())) {
			return searchByStandard(searchStudentDetailsDTO);
		}
		
		if(StringUtils.isNotBlank(searchStudentDetailsDTO.getStandard()) 
				&& StringUtils.isNotBlank(searchStudentDetailsDTO.getStudentCode())
				&& StringUtils.isBlank(searchStudentDetailsDTO.getGrade())) {
			return searchStudentByStandard(searchStudentDetailsDTO);
		}
		
		if(StringUtils.isNotBlank(searchStudentDetailsDTO.getStandard()) && StringUtils.isNotBlank(searchStudentDetailsDTO.getGrade())
				&& StringUtils.isBlank(searchStudentDetailsDTO.getStudentCode())) {
			return null;
		}
		return null;
	}
	
	private List<StudentCareerDetails> searchByStandard(SearchStudentDetailsDTO searchStudentDetailsDTO) {
		List<StudentCareerDetails> studentsMarkInfo = StudentMarksInfo.studentsMarksList;
		Predicate<StudentCareerDetails> studentPredicate = (studentCareerDetails) -> {
			return studentCareerDetails.getStandard().equals(searchStudentDetailsDTO.getStandard());
		};
		List<StudentCareerDetails> marksList = studentsMarkInfo.stream().filter(studentPredicate).collect(Collectors.toList());
		System.out.println(" The Marks Details :: "+marksList.size());
		return marksList;
	}
	
	private List<StudentCareerDetails> searchStudentByStandard(SearchStudentDetailsDTO searchStudentDetailsDTO) {
		List<StudentCareerDetails> studentsMarkInfo = StudentMarksInfo.studentsMarksList;
		Predicate<StudentCareerDetails> studentPredicate = (studentCareerDetails) -> {
			return studentCareerDetails.getStandard().equals(searchStudentDetailsDTO.getStandard()) && 
					studentCareerDetails.getStudentCode().equals(searchStudentDetailsDTO.getStudentCode());
		};
		List<StudentCareerDetails> marksList = studentsMarkInfo.stream().filter(studentPredicate).collect(Collectors.toList());
		
		System.out.println(" The Marks Details :: "+marksList.size());
		return marksList;
	}
	
	@SuppressWarnings("unused")
	private StudentCareerDetails searchGradeByStandard(SearchStudentDetailsDTO searchStudentDetailsDTO) {
		List<StudentCareerDetails> studentsMarkInfo = StudentMarksInfo.studentsMarksList;
		Predicate<StudentCareerDetails> studentPredicate = (studentCareerDetails) -> {
			return studentCareerDetails.getStudentCode().equals(searchStudentDetailsDTO.getStudentCode());
		};
		Stream<StudentCareerDetails> marksStream = studentsMarkInfo.stream().filter(studentPredicate).distinct();
		StudentCareerDetails studentMarks = marksStream.collect(Collectors.toList()).size() > 0 ? 
																marksStream.collect(Collectors.toList()).get(0) : null ;
		return studentMarks;
	}
	
}
